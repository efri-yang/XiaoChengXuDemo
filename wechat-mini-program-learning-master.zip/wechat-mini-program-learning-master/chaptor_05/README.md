### 微信小程序用户数据解密（2016-11-24）
- 根据code换取sessionsession_key和openid
- 用户敏感数据解密