// about.js

// 获取应用实例
let app = getApp()

Page({
    back () {
        wx.navigateBack()
    }
})
