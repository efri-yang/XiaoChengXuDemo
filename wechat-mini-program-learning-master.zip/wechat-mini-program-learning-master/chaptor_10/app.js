//app.js
App({
  onLaunch: function () {
    
  },
  globalData:{
    userInfo:null
  }
})