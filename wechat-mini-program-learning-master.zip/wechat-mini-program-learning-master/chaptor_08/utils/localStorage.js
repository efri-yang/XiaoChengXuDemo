var add = function(key, data, expires){
    var timestamp=new Date().getTime();
    return timestamp;
}
module.exports = {
    add: add
}