//app.js
let {WeToast} = require('src/wetoast.js')

//注册小程序，接收一个Object参数
App({
	WeToast
})